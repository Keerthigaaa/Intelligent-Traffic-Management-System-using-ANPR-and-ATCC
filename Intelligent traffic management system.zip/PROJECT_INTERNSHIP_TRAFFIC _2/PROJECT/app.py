from flask import Flask, render_template, request, redirect, url_for, jsonify, Response
import os
from werkzeug.utils import secure_filename
import cv2
from app_instance import create_app
from dotenv import load_dotenv
import pymysql




# Load environment variables from .env file
load_dotenv()

# Initialize the app using the create_app function
app = create_app()

# Fetch camera IPs from environment variables (comma-separated list)
camera_ips_env = os.getenv('LIVE_CCTV_IPS', '')
if camera_ips_env:
    app.config['CAMERA_IPS'] = camera_ips_env.split(',')
else:
    app.config['CAMERA_IPS'] = []

UPLOAD_FOLDER = app.config['UPLOAD_FOLDER']
ALLOWED_EXTENSIONS = {'mp4', 'avi', 'mov', 'mkv'}
os.makedirs(UPLOAD_FOLDER, exist_ok=True)

# Helper functions
def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS



def dbconnection():
     connection = pymysql.connect(host='127.0.0.1',database='traffic management system',user='root',password='greesh09@25M')
     return connection


# Routes
@app.route('/')
def login():
    return render_template('login.html')

@app.route('/validate_login', methods=['POST'])
def validate_login():
    username = request.form.get('username')
    password = request.form.get('password')
    connection = dbconnection()
    print(f"number_plate......................{connection}")
    print(username, password)
    with connection.cursor() as cursor:
        # Use parameterized query to prevent SQL injection
        sql_query = "SELECT * FROM login_details WHERE username = %s AND password = %s"
        cursor.execute(sql_query, (username, password))
        result = cursor.fetchone() 
        print("SQL Statement Executed:", sql_query)
        if result:
            print(f"User {username} logged in successfully.")
            return redirect(url_for('home'))
    
    return render_template('login.html', error="Invalid username or password.")


@app.route('/home')
def home():
    return render_template('home.html')


import pymysql

@app.route('/search', methods=['GET', 'POST'])
def search_license_plate():
    number_plate = request.form.get('number_plate')  # Get license plate from form
    connection = dbconnection()
    print(f"Database Connection: {connection}")
    vehicle_data = None
    error = None
    if request.method == 'POST' and number_plate:
        with connection.cursor(pymysql.cursors.DictCursor) as cursor:
            # Use parameterized query to prevent SQL injection
            sql_query = "SELECT * FROM vehicle_data WHERE number_plate = %s"
            cursor.execute(sql_query, (number_plate,))
            result = cursor.fetchone()  # Fetch single record
            print("SQL Statement Executed:", sql_query)
            if result:
                print(f"Vehicle data found for {number_plate}")
                vehicle_data = result  # No need to manually map if using DictCursor
            else:
                error = "No details found for the entered number plate."

    return render_template('search.html', vehicle_data=vehicle_data, error=error)

################################################################################

@app.route('/upload_video', methods=['GET', 'POST'])
def upload_video():
    if request.method == 'POST':
        if 'file' not in request.files:
            return render_template('upload_video.html', error="No file selected.")
        file = request.files['file']
        if file and allowed_file(file.filename):
            filename = secure_filename(file.filename)
            file.save(os.path.join(app.config['UPLOAD_FOLDER'], filename))
            return render_template('upload_video.html', success=True)
    return render_template('upload_video.html')


@app.route('/reports', methods=['GET'])
def reports():
    return render_template('reports.html')

@app.route('/results', methods=['GET'])
def results():
    return render_template('results.html')

@app.route('/logout')
def logout():
    return redirect(url_for('login'))


@app.route('/live_monitoring', methods=['GET'])
def live_monitoring():
    #cctv_ips = app.config['CAMERA_IPS']
    return render_template('live_monitoring.html')

######################################################################################################

from anpr_video import PlateFinder
from anpr_video import OCR

from ultralytics import YOLO
from atcc_final import *
from heatmap_visualization import *

# Load the YOLO model
atcc_model = YOLO("yolov8n.pt")

# Load ANPR model
findPlate = PlateFinder(minPlateArea=4100, maxPlateArea=15000)

model = OCR(modelFile=r"C:\Users\mgree\Downloads\PROJECT_INTERNSHIP_TRAFFIC _2\PROJECT_INTERNSHIP_TRAFFIC _2\PROJECT\models\binary_128_0.50_ver3.pb", 
             labelFile=r"C:\Users\mgree\Downloads\PROJECT_INTERNSHIP_TRAFFIC _2\PROJECT_INTERNSHIP_TRAFFIC _2\PROJECT\models\binary_128_0.50_labels_ver2.txt")

#####################################################################################################################
def generate_atcc_frames(video_path, model):
    """Generate ATCC processed video frames."""
    cap = cv2.VideoCapture(video_path)
    try:
        while cap.isOpened():
            success, frame = cap.read()
            if not success:
                break
            # Process the frame using the YOLO model
            results = model(frame, imgsz=640)
            for result in results:
                boxes = result.boxes
                for box in boxes:
                    x1, y1, x2, y2 = map(int, box.xyxy[0].tolist())
                    conf = box.conf[0]
                    label = result.names[int(box.cls[0])]
                    cv2.rectangle(frame, (x1, y1), (x2, y2), (0, 255, 0), 2)
                    cv2.putText(frame, f'{label} {conf:.2f}', (x1, y1 - 10),
                                cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 255, 0), 2)
            # Encode and yield frames
            _, buffer = cv2.imencode('.jpg', frame)
            yield (b'--frame\r\n'
                   b'Content-Type: image/jpeg\r\n\r\n' + buffer.tobytes() + b'\r\n')
    except Exception as e:
        print(f"Error in video processing: {e}")
    finally:
        cap.release()


@app.route('/start_processing', methods=['POST'])
def start_processing():
    """Handle form submission and start video processing."""
    process_type = request.form.get('processType')
    num_cameras = int(request.form.get('numCameras', 0))
    input_files = []

    # Save uploaded files
    for i in range(1, num_cameras + 1):
        file = request.files.get(f'cameraFile{i}')
        if file:
            filepath = os.path.join(UPLOAD_FOLDER, file.filename)
            file.save(filepath)
            input_files.append(filepath)

    # Handle processes
    if process_type.lower() == 'atcc':
        return render_template('atcc_view.html', video_paths=input_files, process="ATCC")
    elif process_type.lower() == 'anpr':
        return render_template('processed_video.html', video_paths=input_files, process="ANPR")
    else:
        return "Invalid process type selected", 400


@app.route('/video_feed/<process>/<path:video_path>')
def video_feed(process, video_path):
    """Stream video feed based on the selected process."""
    if process == "ATCC":
        return Response(generate_atcc_frames(video_path, atcc_model), mimetype='multipart/x-mixed-replace; boundary=frame')
    elif process == "ANPR":
        return "ANPR processing not implemented yet", 501  # Placeholder for ANPR logic
    else:
        return "Invalid process type", 400


if __name__ == "__main__":
    # Create the upload folder if it does not exist
    os.makedirs(UPLOAD_FOLDER, exist_ok=True)
    app.run(debug=True)