from celery import Celery
import os
#from models.ATCC import process_videos, initialize_video_captures, load_model

app = Celery('tasks', broker='redis://localhost:6379/0')

@app.task
def process_video_task(video_path):
    # Add your video processing logic here
    process_videos(video_path)  # Example function from Step 2
